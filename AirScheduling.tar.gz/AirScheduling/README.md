AirScheduling
=============
Práctica de Algoritmia de la FIB sobre la assignación de pilotos a vuelos en un horario.

### Compilación y ejecución: ###
Para poder ejecutar la practica solo hace falta hacer make y ejecutar el programa:

./practicaVersio1 < nombreInstance.air > ficheroSalida

### Práctica hecha por: ###

* Albert Gili Zaragoza
* Marc Garcia Roig
